import 'package:eventbuzz/widget_tree1.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'widgets/clubs.dart';
import 'package:flutter/material.dart';
import 'widgets/Home.dart';
import 'widgets/login.dart';
import 'widgets/Clubhome.dart';
import 'widgets/sports.dart';
import 'widgets/sporthome.dart';
import 'widgets/Clubhead_home.dart';
import 'widgets/createevent.dart';
import 'widgets/editevent.dart';
import 'widgets/EventViewPage.dart';
import 'widgets/admin_home.dart';
import 'widgets/add_club.dart';
import 'widgets/view_cs.dart';
import 'widgets/view_clubs.dart';
import 'widgets/view_sports.dart';
import 'widgets/edit_club.dart';
import 'widgets/edit_sports.dart';
import 'widgets/viewcsheads.dart';
import 'widgets/venue_master.dart';
import 'widgets/add_venue.dart';
import 'widgets/requests.dart';
import 'package:eventbuzz/widget_tree.dart';
import 'package:firebase_core/firebase_core.dart';
Future<void> main () async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp( MyApp());

}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: StreamBuilder<User?>(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (BuildContext context, AsyncSnapshot snapshot) {
          if(snapshot.hasError)
          {
            return Text(snapshot.error.toString());
          }
          if(snapshot.connectionState==ConnectionState.active)
          {
            if(snapshot.data == null)
            {
              return LoginScreen();
            }
            else if(snapshot.data!.providerData.any(
                  (userInfo) => userInfo.providerId == "password",
            ))
            {
            if(FirebaseAuth.instance.currentUser?.uid == 'gIbjzTKpEkc3GTmxmWrZuFhetem1') {
              return Clubhead_home();
            }
            else
              return Admin_home();
            }
            else
              {
                return Home();
              }
          }
          return Center(child: CircularProgressIndicator());
        },
      ),
      routes: {
        // '/': (BuildContext context) => LoginScreen(),
        '/home': (context) => Home(),
        '/clubs': (context) => ClubPage(),
        '/sports': (context) => SportPage(),
        '/clubhome': (context) => Clubhome(),
        '/sporthome': (context) => Sporthome(),
        '/Clubhead_home': (context) => Clubhead_home(),
        '/createevent': (context) => createevent(),
        '/editevent': (context) => editevent(),
        '/viewevent': (context) => viewevent(),
        '/widget_tree': (context) => WidgetTree(),
        '/admin_home': (context)=>Admin_home(),
        '/addclub': (context)=>Add_club(),
        '/view_CS': (context)=>View_cs(),
        '/view_clubs': (context)=>A(),
        '/view_sports': (context)=>view_sports(),
        '/editclub': (context)=>Edit_club(),
        '/editsports': (context)=>Edit_sports(),
        '/csheads' : (context)=>csheads(),
        '/venue_master' : (context)=>vvenues(),
        '/add_venue' : (context)=>Add_venue(),
        '/requests' : (context)=>Request(),
        '/login': (context)=>LoginScreen(),
        '/widget_tree1': (context)=>WidgetTree1(),
      },
      debugShowCheckedModeBanner: false,
    );
  }
}
