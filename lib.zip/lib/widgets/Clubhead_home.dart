import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'head_Upcoming_Page.dart';
import 'head_Ongoing_Page.dart';
import 'head_Past_Page.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:eventbuzz/auth.dart';
class Clubhead_home extends StatefulWidget {
  const Clubhead_home({Key? key}) : super(key: key);
  @override
  State<Clubhead_home> createState() => _Clubhead_homeState();
}

final PageController _pageController = PageController();


class _Clubhead_homeState extends State<Clubhead_home> {
  final User? user = Auth().currentUser;

  Future<void> signOut() async {
    await Auth().signOut();
  }
  Widget _signOutButton()
  {
    return ElevatedButton(
      onPressed: signOut,
      child: const Text('Sign Out'),
    );
  }
  int _selectedIndex = 0;
  String selectedType = '';

  final List<String> _accountTypes = [
    'Club 1',
    'Club 2',
  ];
  String selectedType2 = '';

  final List<String> _accountTypes2 = [
    'Sport 1',
    'Sport 2',
  ];



  static final List<Widget> _pages = <Widget>[


    PageView(
      controller: _pageController,
      children: [
        head_Upcoming_Page('Upcoming Events'),
        head_Ongoing_Page('Ongoing Events'),
        head_Past_Page('Past Events'),
      ],
    ),
    Icon(
      Icons.notifications,
      size: 150,
    ),
  ];
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }
  onWillPop(context) async {
    SystemChannels.platform.invokeMethod('SystemNavigator.pop');
    return false;
  }
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () => onWillPop(context),
      child: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          title: const Text(
            'Club Head Home Page',
          ),
          backgroundColor: const Color(0xff764abc),
        ),

        drawer: Drawer(
          child: ListView(
            // Important: Remove any padding from the ListView.
            padding: EdgeInsets.zero,
            children: [
              const DrawerHeader(
                decoration: BoxDecoration(
                  color: Colors.blue,
                ),
                child: Text('',
                  style:TextStyle(
                    fontSize: 30,
                  ),),
              ),
              _signOutButton(),
            ],
          ),
        ),
        body: Stack(
          children: [
            Center(
              child: _pages.elementAt(_selectedIndex),
              // PageView(
              //   controller: _pageController,
              //   children: [
              //     Upcoming_Page('Upcoming Events'),
              //     Ongoing_Page('Ongoing Events'),
              //     Past_Page('Past Events'),
              //   ],
            ),
            // ),
          ],
        ),

        bottomNavigationBar: BottomNavigationBar(
          items: const <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              icon: Icon(Icons.home),
              label: 'Home',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.notifications),
              label: 'Notifications',
            ),

          ],
          selectedItemColor: Colors.black,
          currentIndex: _selectedIndex,
          onTap: _onItemTapped,
        ),
      ),
    );
  }
}

