import 'package:flutter/material.dart';


class Add_venue extends StatefulWidget {
  @override
  _Add_venueState createState() => _Add_venueState();
}

class _Add_venueState extends State<Add_venue> {
  String _eventName = '';






  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Venue'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              TextField(
                decoration: InputDecoration(
                    labelText: 'Enter Venue',
                    prefixIcon: Icon(Icons.place,color: Colors.blue,)
                ),
                onChanged: (value) {
                  setState(() {
                    _eventName = value;
                  });
                },
              ),
              SizedBox(height: 16.0),
              ElevatedButton(
                child: Text('Add Venue'),

                onPressed: () {
                  // TODO: Save event details to database or do something else
                  // with the event details
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
