import 'dart:async';

import 'package:flutter/material.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import 'view_liked_clubs.dart';
import 'view_liked_events.dart';
import 'Past_Events.dart';
import 'Ongoing_Events.dart';
import 'Upcoming_Events.dart';
class ClubPage extends StatefulWidget {
  @override
  _ClubPageState createState() => _ClubPageState();
}

class _ClubPageState extends State<ClubPage> {
  final List<Event> _clubEvents = [
    Event(name: 'Adventure', venue: 'ELHC 403'),
  ];

  List<Event> _filteredEvents = [];

  TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    _filteredEvents = _clubEvents;
    super.initState();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Club Events'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                labelText: 'Search by name or venue',
                border: OutlineInputBorder(),
                suffixIcon: IconButton(
                  icon: Icon(Icons.clear),
                  onPressed: () {
                    _searchController.clear();
                    _filterEvents('');
                  },
                ),
              ),
              onChanged: (value) {
                _filterEvents(value);
              },
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: _filteredEvents.length,
              itemBuilder: (BuildContext context, int index) {
                Event event = _filteredEvents[index];
                return ListTile(
                  title: Text(event.name),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    //children: [
                    //Text(event.rating.toString()),
                    //IconButton(
                    //icon: Icon(Icons.star),
                    //onPressed: () {
                    // handle rating
                    //},
                  ),
                  onTap: (){
                    Navigator.pushNamed(context, '/clubhome');
                  },
                  //],
                  //),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  void _filterEvents(String query) {
    setState(() {
      _filteredEvents = _clubEvents
          .where((event) =>
      event.name.toLowerCase().contains(query.toLowerCase()) ||
          event.venue.toLowerCase().contains(query.toLowerCase()))
          .toList();
    });
  }
}

class Event {
  final String name;
  final String venue;


  Event({required this.name, required this.venue});
}
