// import 'dart:js';
import 'package:flutter/material.dart';
import 'event.dart';
import 'createevent.dart';
class view_sports extends StatefulWidget {


  @override
  State<view_sports> createState() => _view_sportsState();
}

class _view_sportsState extends State<view_sports> {

  List<event> _filteredEvents = [];
  List<event> events=[
    event('KoKogirls','Vhawdd','1as0','asa11','asadh'),
    event('KoKo mens','Vhaffd','1as0','asa11','asadh'),

  ];
  TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    _filteredEvents = events;
    super.initState();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text(
          'View Sports',
        ),
        backgroundColor: const Color(0xff764abc),
      ),

      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 5,),


            Column(
              children: events.map((event)=> eventtemplate(event,context)).toList(),
            ),
          ],
        ),
      ),

    );
  }

  void _filterEvents(String query) {
    setState(() {
      _filteredEvents = events.where((event) =>
      event.name!.toLowerCase().contains(query.toLowerCase()) ||
          event.venue!.toLowerCase().contains(query.toLowerCase()))
          .toList();
    });
  }
}

Widget eventtemplate (event,BuildContext context)
{
  return Card(

      margin: EdgeInsets.fromLTRB(16.0, 16.0, 16.0, 0.0),
      child: InkWell(
        onTap: (){
          Navigator.pushNamed(context, '/viewevent');
        },
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Row(
                children: <Widget>[
                  Expanded(
                    flex: 4,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        SizedBox(width: 10,),
                        Text(
                            event.name,
                            style: TextStyle(
                              fontSize: 18.0,
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                            )
                        ),
                        SizedBox(width: 10,),
                        Text(
                            event.venue,
                            style: TextStyle(
                              fontSize: 18.0,
                              fontWeight: FontWeight.bold,
                              color: Colors.black,
                            )
                        ),
                        SizedBox(width: 10,),
                        Text(
                            event.timings,
                            style: TextStyle(
                              fontSize: 18.0,
                              fontWeight: FontWeight.bold,
                              color: Colors.black,
                            )
                        ),
                        SizedBox(width: 10,),
                        Text(
                            event.date,
                            style: TextStyle(
                              fontSize: 18.0,
                              fontWeight: FontWeight.bold,
                              color: Colors.black,
                            )
                        ),
                      ],
                    ),
                  ),
                  SizedBox(width: 20,),
                  Expanded(
                    flex: 3,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        CircleAvatar(
                          backgroundImage: AssetImage('assets/slider2.jpeg'),
                          radius: 40.0,
                        ),
                      ],
                    ),
                  ) ,
                ],
              ),
              SizedBox(height: 10,),
              Padding(
                padding: const EdgeInsets.fromLTRB(0, 0, 24, 0),
                child: Container(
                  // width: 40,
                  // color: Colors.grey[500],

                  // child: Icon(Icons.mode_edit_outline)
                  child: IconButton(
                      onPressed: (){
                        Navigator.pushNamed(context, '/editsports');
                      },
                      icon:   Icon(Icons.mode_edit_outline)),
                ),
              )
            ],
          ),
        ),
      )
  );
}