import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';


class Add_club extends StatefulWidget {
  @override
  _Add_clubState createState() => _Add_clubState();
}

class _Add_clubState extends State<Add_club> {
  String _eventName = '';
  String _eventVenue = '';
  String _eventImageUrl = '';





  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Club/Sports'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              TextField(
                decoration: InputDecoration(
                  labelText: 'Enter Name',
                  prefixIcon: Icon(Icons.house_rounded,color: Colors.blue,),
                ),
                onChanged: (value) {
                  setState(() {
                    _eventName = value;
                  });
                },
              ),
              SizedBox(height: 16.0),

              TextField(
                decoration: InputDecoration(
                  labelText: 'Head Name',
                  prefixIcon: Icon(Icons.person,color: Colors.blue,),
                ),
                onChanged: (value) {
                  setState(() {
                    _eventVenue = value;
                  });
                },
              ),
              SizedBox(height: 16.0),


              TextField(
                decoration: const InputDecoration(
                  labelText: 'Head email',
                  prefixIcon: Icon(
                    Icons.email,
                    color: Colors.blue,
                  ),
                ),
                onChanged: (value) {
                  setState(() {
                    _eventVenue = value;
                  });
                },
              ),



              SizedBox(height: 16.0,),
              TextField(
                decoration: InputDecoration(
                  labelText: 'Head mobile number',
                  prefixIcon: Icon(Icons.mobile_friendly_rounded,color: Colors.blue,),
                ),
                onChanged: (value) {
                  setState(() {
                    _eventVenue = value;
                  });
                },
              ),
              SizedBox(height: 16.0,),
              TextField(
                decoration: InputDecoration(
                  labelText: 'Description',
                  prefixIcon: Icon(Icons.description,color: Colors.blue,),
                ),
                onChanged: (value) {
                  setState(() {
                    _eventImageUrl = value;
                  });
                },
              ),
              SizedBox(height: 16.0,),
              TextField(
                decoration: InputDecoration(
                  labelText: 'Image Url',
                  prefixIcon: Icon(Icons.link,color: Colors.blue,),
                ),
                onChanged: (value) {
                  setState(() {
                    _eventImageUrl = value;
                  });
                },
              ),
              SizedBox(height: 32.0),
              ElevatedButton(
                child: Text('Create Event'),
                onPressed: () {
                  // TODO: Save event details to database or do something else
                  // with the event details
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
