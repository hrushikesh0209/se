import 'dart:async';

import 'package:flutter/material.dart';

class SportPage extends StatefulWidget {
  @override
  _SportPageState createState() => _SportPageState();
}

class _SportPageState extends State<SportPage> {
  List<Event> _sportEvents = [
    Event(name: 'KhoKho', venue: 'Court'),
  ];

  List<Event> _filteredEvents = [];

  TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    _filteredEvents = _sportEvents;
    super.initState();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Sport Events'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                labelText: 'Search by name or venue',
                border: OutlineInputBorder(),
                suffixIcon: IconButton(
                  icon: Icon(Icons.clear),
                  onPressed: () {
                    _searchController.clear();
                    _filterEvents('');
                  },
                ),
              ),
              onChanged: (value) {
                _filterEvents(value);
              },
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: _filteredEvents.length,
              itemBuilder: (BuildContext context, int index) {
                Event event = _filteredEvents[index];
                return ListTile(
                  onTap: (){
                    Navigator.pushNamed(context, '/sporthome');
                  },
                  title: Text(event.name),
                  subtitle: Text(event.venue),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                  )
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  void _filterEvents(String query) {
    setState(() {
      _filteredEvents = _sportEvents
          .where((event) =>
      event.name.toLowerCase().contains(query.toLowerCase()) ||
          event.venue.toLowerCase().contains(query.toLowerCase()))
          .toList();
    });
  }
}

class Event {
  final String name;
  final String venue;


  Event({required this.name, required this.venue});
}
