// import 'dart:js';
import 'package:flutter/material.dart';
import 'event.dart';
import 'createevent.dart';
import 'dart:core';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class AboutWidget extends StatelessWidget {
  const AboutWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Approve Event?'),
      content: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Text('Are you sure you want to approve this event?'),
          ],
        ),
      ),
      actions: <Widget>[
        TextButton(
          child: Text('Confirm'),
          onPressed: () {
            print('Confirmed');
            Navigator.of(context).pop();
          },
        ),
        TextButton(
          child: Text('Cancel'),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ],
    );

  }
}

class Deny extends StatelessWidget {
  const Deny({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Deny Event?'),
      content: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Text('Are you sure you want to deny this event?'),
          ],
        ),
      ),
      actions: <Widget>[
        TextButton(
          child: Text('Confirm'),
          onPressed: () {
            print('Confirmed');
            Navigator.of(context).pop();
          },
        ),
        TextButton(
          child: Text('Cancel'),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ],
    );
  }
}


class Request extends StatefulWidget {


  @override
  State<Request> createState() => _RequestState();
}

class _RequestState extends State<Request> {

  List<event> _filteredEvents = [];
  List<event> events = [
    event('Robo', 'Vhawdd', '1as0', 'asa11', 'asadh'),
    event('Roboad', 'Vhaffd', '1as0', 'asa11', 'asadh'),
    event('Roboads', 'Vhawdwd', '1as0', 'asa11', 'asadh'),
    event('Roboadsd', 'Vhawd', '1as0', 'asa11', 'asadh'),
    event('Robocd', 'Vhadfww', '1as0', 'asa11', 'asadh'),
  ];
  TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    _filteredEvents = events;
    super.initState();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text(
          'View Clubs',
        ),
        backgroundColor: const Color(0xff764abc),
      ),

      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 5,),


            Column(
              children: events.map((event) => eventtemplate(event, context))
                  .toList(),
            ),
          ],
        ),
      ),

    );
  }

  void _filterEvents(String query) {
    setState(() {
      _filteredEvents = events.where((event) =>
      event.name!.toLowerCase().contains(query.toLowerCase()) ||
          event.venue!.toLowerCase().contains(query.toLowerCase()))
          .toList();
    });
  }
}

Widget eventtemplate (event,BuildContext context)
{
  return Card(

      margin: EdgeInsets.fromLTRB(16.0, 16.0, 16.0, 0.0),
      child: InkWell(
        onTap: (){
          Navigator.pushNamed(context, '/viewevent');
        },
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Row(
                children: <Widget>[
                  Expanded(
                    flex: 4,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        SizedBox(width: 10,),
                        Text(
                            event.name,
                            style: TextStyle(
                              fontSize: 18.0,
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                            )
                        ),
                        SizedBox(width: 10,),
                        Text(
                            event.venue,
                            style: TextStyle(
                              fontSize: 18.0,
                              fontWeight: FontWeight.bold,
                              color: Colors.black,
                            )
                        ),
                        SizedBox(width: 10,),
                        Text(
                            event.timings,
                            style: TextStyle(
                              fontSize: 18.0,
                              fontWeight: FontWeight.bold,
                              color: Colors.black,
                            )
                        ),
                        SizedBox(width: 10,),
                        Text(
                            event.date,
                            style: TextStyle(
                              fontSize: 18.0,
                              fontWeight: FontWeight.bold,
                              color: Colors.black,
                            )
                        ),
                      ],
                    ),
                  ),
                  SizedBox(width: 20,),
                  Expanded(
                    flex: 3,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        CircleAvatar(
                          backgroundImage: AssetImage('assets/slider2.jpeg'),
                          radius: 40.0,
                        ),
                      ],
                    ),
                  ) ,
                ],
              ),
              SizedBox(height: 10,),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                // width: 40,
                // color: Colors.grey[500],

                // child: Icon(Icons.mode_edit_outline)
                  children: [
                    IconButton(

                      onPressed: ()=> showDialog(
                        context: context,
                        builder: (context) => AboutWidget(),
                      ),

                      icon:   Icon(Icons.check),
                    ),
                    IconButton(

                      onPressed: ()=> showDialog(
                        context: context,
                        builder: (context) => Deny(),
                      ),

                      icon:   Icon(FontAwesomeIcons.xmark),
                    ),
                  ]

              )
            ],
          ),
        ),
      )
  );
}