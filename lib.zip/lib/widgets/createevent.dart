
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';


class createevent extends StatefulWidget {
  @override
  _createeventState createState() => _createeventState();
}

class _createeventState extends State<createevent> {
  final _firestore = FirebaseFirestore.instance;
  String _eventName = '';
  String _eventDate = '';
  String _startTime = '';
  String _endTime = '';
  String _eventVenue = '';
  String _eventImageUrl = '';
  String _eventDesc = '';
  String _eventclubname = '';





  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Create Event'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              TextField(
                decoration: InputDecoration(
                  labelText: 'Event Name',
                ),
                onChanged: (value) {
                    _eventName = value;
                },
              ),
              SizedBox(height: 16.0),
              TextField(
                decoration: InputDecoration(
                  labelText: 'Event Description',
                ),
                onChanged: (value) {
                    _eventDesc = value;
                },
              ),
              SizedBox(height: 16.0),
              TextField(
                decoration: InputDecoration(
                  labelText: 'Event Club Name',
                ),
                onChanged: (value) {
                    _eventclubname = value;
                },
              ),
              SizedBox(height: 16.0),
              TextField(
                decoration: InputDecoration(
                  labelText: 'Date, format like YYYY-MM-DD',
                ),
                onChanged: (value) {
                  _eventDate = value;
                },
              ),
              SizedBox(height: 16.0),

              TextField(
                decoration: InputDecoration(
                  labelText: 'Start time, format like 19:00',
                ),
                onChanged: (value) {
                  _startTime = value;
                },
              ),
              SizedBox(height: 16.0),
              TextField(
                decoration: InputDecoration(
                  labelText: 'End Time, format like 20:00',
                ),
                onChanged: (value) {
                  _endTime = value;
                },
              ),
              SizedBox(height: 16.0),
              TextField(
                decoration: InputDecoration(
                  labelText: 'Event Venue',
                ),
                onChanged: (value) {
                    _eventVenue = value;
                },
              ),
              SizedBox(height: 16.0),
              TextField(
                decoration: InputDecoration(
                  labelText: 'Image URL',
                ),
                onChanged: (value) {
                    _eventImageUrl = value;
                },
              ),
              SizedBox(height: 32.0),
              ElevatedButton(
                child: Text('Create Event'),
                onPressed: () {
                  FirebaseFirestore.instance.collection('events').add(
                   {
                     'clubname' : _eventclubname,
                     'name' : _eventName,
                     'url' : _eventImageUrl,
                     'venue' : _eventVenue,
                     'endtime' : _endTime,
                     'email' : FirebaseAuth.instance.currentUser?.email,
                     'starttime' : _startTime,
                      'date' : _eventDate,
                     'description': _eventDesc,

                   }
                  );
                  Navigator.pushNamed(context, '/Clubhead_home');

                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
