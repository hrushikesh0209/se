import 'package:flutter/material.dart';
import 'event.dart';
import 'venueclass.dart';
class vvenues extends StatefulWidget {


  vvenues();
  @override
  State<vvenues> createState() => _vvenuesState();
}

class _vvenuesState extends State<vvenues> {

  List<venues> _filteredEvents = [];
  List<venues> events=[
    venues('Vhawdd',),
    venues('Vhaffd',),

  ];
  TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    _filteredEvents = events;
    super.initState();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.pushNamed(context, '/add_venue');
        },
        child: Icon(Icons.add,
          color: Colors.white,
        ),
        backgroundColor: Colors.blue,
      ),
      appBar: AppBar(
        title: const Text('Venues'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 5,),

            SizedBox(height: 5,),

            Column(
              children: events.map((venue)=> headtemplate(venue,context)).toList(),
            ),
          ],
        ),
      ),

    );
  }


}


Widget headtemplate (venue, BuildContext context)
{
  return Card(

      margin: EdgeInsets.fromLTRB(16.0, 16.0, 16.0, 0.0),
      shape: RoundedRectangleBorder( //<-- 1. SEE HERE
        side: BorderSide(
          color: Colors.greenAccent,
          width: 3,
        ),
        borderRadius: BorderRadius.circular(20.0),
      ),
      child: new InkWell(
        onTap: (){
          Navigator.pushNamed(context, '/viewevent');
        },
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Row(
            children: <Widget>[
              Expanded(
                flex: 4,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    SizedBox(width: 10,),
                    Text(
                        venue.venue,
                        style: TextStyle(
                          fontSize: 18.0,
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                        )
                    ),
                    SizedBox(width: 10,),

                  ],
                ),
              ),
            ],
          ),
        ),
      )
  );
}