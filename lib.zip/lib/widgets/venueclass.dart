class venues{

  String? venue;


  venues(String venue,){
    this.venue=venue;
  }

}