import 'package:flutter/material.dart';

class viewevent extends StatefulWidget {
  const viewevent({super.key});

  @override
  State<viewevent> createState() => _vieweventState();
}

class _vieweventState extends State<viewevent> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Event Details'),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            // Image.network("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQAuHlbrw17HuaoiWxbtCDztBZ6sZv9f_P01Ik4uFZLYgmU3yfEW4iRk2l9C5C-ivrNiGw&usqp=CAU",
            Image.asset('assets/slider2.jpeg',
              height: 200,
              fit: BoxFit.cover,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const SizedBox(height: 16.0),
                  Text(
                    'Title of the Event',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 8.0),
                  Row(
                    children: const <Widget>[
                      Icon(Icons.access_time),
                      SizedBox(width: 8.0),
                      Text('Time: 10:00 AM - 2:00 PM'),
                    ],
                  ),
                  const SizedBox(height: 8.0),
                  Row(
                    children: const <Widget>[
                      Icon(Icons.calendar_today),
                      SizedBox(width: 8.0),
                      Text('Date: 25 March 2023'),
                    ],
                  ),
                  const SizedBox(height: 8.0),
                  Row(
                    children: const <Widget>[
                      Icon(Icons.location_on),
                      SizedBox(width: 8.0),
                      Text('Venue: Rajpath, NITC'),
                    ],
                  ),
                  const SizedBox(height: 16.0),
                  Text(
                    'Description: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam suscipit dolor sed elit commodo, id mollis quam iaculis. Donec euismod libero sed.',
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),

    );
  }
}


