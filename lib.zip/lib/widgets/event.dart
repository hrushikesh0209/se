class event{

  String? name;
  String? venue;
  String? timings;
  String? date;
  String? url;

  event(String name,String venue,String timings,String date,String url)
  {
    this.name=name;
    this.venue=venue;
    this.timings=timings;
    this.date=date;
    this.url=url;
  }

}