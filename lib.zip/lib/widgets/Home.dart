import 'dart:async';
import 'package:eventbuzz/auth.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:eventbuzz/widgets/login.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'view_liked_clubs.dart';
import 'view_liked_events.dart';
import 'Past_Events.dart';
import 'Ongoing_Events.dart';
import 'Upcoming_Events.dart';
class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);
  @override
  State<Home> createState() => _HomeState();
}

final PageController _pageController = PageController();


class _HomeState extends State<Home> {

  int _selectedIndex = 0;
  String selectedType = '';

  final List<String> _accountTypes = [
    'Club 1',
    'Club 2',
  ];
  String selectedType2 = '';

  final List<String> _accountTypes2 = [
    'Sport 1',
    'Sport 2',
  ];


  static final List<Widget> _pages = <Widget>[


    PageView(
      controller: _pageController,
      children: [
        Upcoming_Page('Upcoming Events'),
        Ongoing_Page('Ongoing Events'),
        Past_Page('Past Events'),
      ],
    ),
    Icon(
      Icons.notifications,
      size: 150,
    ),
    PageView(
      children: [
        Liked_Clubs('Liked Clubs'),
        Liked_Events('Liked Events'),
      ],
    ),
  ];
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text(
          'Home Page',
        ),
        backgroundColor: const Color(0xff764abc),
      ),
      drawer: Drawer(
        child: ListView(
          // Important: Remove any padding from the ListView.
          padding: EdgeInsets.zero,
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.blue,
              ),
              child: Text('CLUBS AND SPORTS',
              style:TextStyle(
                fontSize: 30,
              ),),
            ),
            ListTile(
              leading: Icon(
                Icons.home,
              ),
              title: const Text('Home'),
              onTap: () {
                Navigator.push(context,MaterialPageRoute(builder: (context) => const Home()));
              },
            ),
            ListTile(
              leading: Icon(
                Icons.music_note,
              ),
              title: const Text('Clubs'),
              onTap: () {
                Navigator.pushNamed(context,'/clubs');
              },
            ),


            ListTile(
              leading: Icon(
                Icons.sports,
              ),
              title: const Text('Sports'),
              onTap: () {
                Navigator.pushNamed(context,'/sports');
              },
            ),
            ListTile(
              leading: IconButton(
                icon: Icon(Icons.logout),
                  onPressed: () async {
                    await GoogleSignIn().signOut();
                    FirebaseAuth.instance.signOut();
                    Navigator.popUntil(context, ModalRoute.withName('/'));
                    // await Auth().signOut();
                  },
              ),
              title: const Text('Logout'),
            ),
          ],
        ),
    ),
      body: Stack(
            children: [
              Center(
                child: _pages.elementAt(_selectedIndex),
                ),
            ],
          ),

      bottomNavigationBar: BottomNavigationBar(
    items: const <BottomNavigationBarItem>[
        BottomNavigationBarItem(
        icon: Icon(Icons.home),
    label: 'Home',
    ),
    BottomNavigationBarItem(
    icon: Icon(Icons.notifications),
    label: 'Notifications',
    ),
    BottomNavigationBarItem(
    icon: Icon(Icons.favorite),
    label: 'Favourites',
    )
    ],
    selectedItemColor: Colors.black,
          currentIndex: _selectedIndex,
          onTap: _onItemTapped,
        ),
    );
  }
}

