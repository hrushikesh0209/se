import 'package:eventbuzz/services/database.dart';
import 'package:eventbuzz/widgets/Clubhead_home.dart';
import 'package:eventbuzz/widgets/Clubhome.dart';
import 'package:eventbuzz/widgets/Home.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:provider/provider.dart';
class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  String selectedType = '';

  // final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login'),
        automaticallyImplyLeading: false,
      ),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 16.0),
                  ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        foregroundColor: Colors.black,
                        minimumSize: Size(double.infinity,50),
                      ),
                      icon: FaIcon(FontAwesomeIcons.google,color:Colors.red),
                      label: Text('Sign Up With Google'),
                      onPressed: () {
                        signInWithGoogle();
                        // final provider =
                        //     Provider.of<GoogleSignInProvider>(context,listen:false);
                        // provider.googleLogin();
                      },
                  ),
                ],
              ),
          ),
            ElevatedButton.icon(
              onPressed: () {

                Navigator.pushNamed(context, '/widget_tree');
              },
              icon: Icon(Icons.navigate_next),
              label: Text('To login as Admin'),
            ),
        ],
      ),
    );
  }
  signInWithGoogle() async {
    GoogleSignInAccount? googleUser= await GoogleSignIn().signIn();
    GoogleSignInAuthentication? googleAuth = await googleUser?.authentication;
    AuthCredential credential = GoogleAuthProvider.credential(
        accessToken: googleAuth?.accessToken,
        idToken: googleAuth?.idToken
    );
    UserCredential user = await FirebaseAuth.instance.signInWithCredential(credential);
    print(user.user?.displayName);
    // var estring = user.user?.email?.substring(-11);
    var estring = user.user?.email?.endsWith('@nitc.ac.in');
    // if(estring == "@nitc.ac.in") {
      if(estring!) {
      if (user.user != null) {
        Navigator.of(context).push(MaterialPageRoute(
          builder: (context) => Home(),
        ));
      }
    }
      else
        {
          await GoogleSignIn().signOut();
          FirebaseAuth.instance.signOut();
          // Navigator.of(context).push(MaterialPageRoute(
          //     builder: (context) => LoginScreen()));
        }
  }

}

