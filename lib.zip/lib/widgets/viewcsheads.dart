import 'package:flutter/material.dart';
import 'event.dart';
import 'csheadclass.dart';
class csheads extends StatefulWidget {


  csheads();
  @override
  State<csheads> createState() => _csheadsState();
}

class _csheadsState extends State<csheads> {

  List<heads> _filteredEvents = [];
  List<heads> events=[
    heads('Robo','Vhawdd','1as0'),
    heads('Roboad','Vhaffd','1as0'),

  ];
  TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    _filteredEvents = events;
    super.initState();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: const Text('CS_heads'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 5,),

            SizedBox(height: 5,),

            Column(
              children: events.map((head)=> headtemplate(head,context)).toList(),
            ),
          ],
        ),
      ),

    );
  }


}


Widget headtemplate (head, BuildContext context)
{
  return Card(

      margin: EdgeInsets.fromLTRB(16.0, 16.0, 16.0, 0.0),
      shape: RoundedRectangleBorder( //<-- 1. SEE HERE
        side: BorderSide(
          color: Colors.greenAccent,
          width: 3,
        ),
        borderRadius: BorderRadius.circular(20.0),
      ),
      child: new InkWell(
        onTap: (){
          Navigator.pushNamed(context, '/viewevent');
        },
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Row(
            children: <Widget>[
              Expanded(
                flex: 4,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    SizedBox(width: 10,),
                    Text(
                        head.csname,
                        style: TextStyle(
                          fontSize: 18.0,
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                        )
                    ),
                    SizedBox(width: 10,),
                    Text(
                        head.name,
                        style: TextStyle(
                          fontSize: 18.0,
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                        )
                    ),
                    SizedBox(width: 10,),
                    Text(
                        head.email,
                        style: TextStyle(
                          fontSize: 18.0,
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                        )
                    ),
                    SizedBox(width: 10,),

                  ],
                ),
              ),
            ],
          ),
        ),
      )
  );
}