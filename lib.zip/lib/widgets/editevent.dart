import 'package:flutter/material.dart';


void main () => runApp(MaterialApp(
  home: editevent(),
));

class editevent extends StatefulWidget {
  @override
  _editeventState createState() => _editeventState();
}

class _editeventState extends State<editevent> {
  String _eventName = '';
  DateTime _eventDate = DateTime.now();
  TimeOfDay _startTime = TimeOfDay.now();
  TimeOfDay _endTime = TimeOfDay.now();
  String _eventVenue = '';
  String _eventImageUrl = '';

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: _eventDate,
        firstDate: DateTime.now(),
        lastDate: DateTime(2100));
    if (picked != null && picked != _eventDate) {
      setState(() {
        _eventDate = picked;
      });
    }
  }

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
        context: context,
        initialTime: _startTime);
    if (picked != null && picked != _startTime) {
      setState(() {
        _startTime = picked;
      });
    }
  }
  Future<void> _selectTime1(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
        context: context,
        initialTime: _endTime);
    if (picked != null && picked != _endTime) {
      setState(() {
        _endTime = picked;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Event Details'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              TextField(
                decoration: InputDecoration(
                  labelText: 'Event Name',
                ),
                onChanged: (value) {
                  setState(() {
                    _eventName = value;
                  });
                },
              ),
              SizedBox(height: 16.0),
              Row(
                children: <Widget>[
                  Expanded(
                    child: Text(
                      'Event Date: ${_eventDate.day}/${_eventDate.month}/${_eventDate.year}',
                    ),
                  ),
                  IconButton(
                    icon: Icon(Icons.calendar_today),
                    onPressed: () => _selectDate(context),
                  ),
                ],
              ),
              SizedBox(height: 16.0),
              Row(
                children: <Widget>[
                  Expanded(
                    child: Text(
                      'Start Time: ${_startTime.hour}:${_startTime.minute}',
                    ),
                  ),

                  IconButton(
                    icon: Icon(Icons.access_time),
                    onPressed: () => _selectTime(context),
                  ),
                ],
              ),
              Row(
                children: <Widget>[
                  Expanded(
                    child: Text(
                      'End Time: ${_endTime.hour}:${_endTime.minute}',
                    ),
                  ),

                  IconButton(
                    icon: Icon(Icons.access_time),
                    onPressed: () => _selectTime1(context),
                  ),
                ],
              ),
              SizedBox(height: 16.0),
              TextField(
                decoration: InputDecoration(
                  labelText: 'Event Venue',
                ),
                onChanged: (value) {
                  setState(() {
                    _eventVenue = value;
                  });
                },
              ),
              SizedBox(height: 16.0),
              TextField(
                decoration: InputDecoration(
                  labelText: 'Image URL',
                ),
                onChanged: (value) {
                  setState(() {
                    _eventImageUrl = value;
                  });
                },
              ),
              SizedBox(height: 32.0),
              ElevatedButton(
                child: Text('Edit Event'),
                onPressed: () {
                  Navigator.pushNamed(context, '/Clubhead_home');
                  // TODO: Save event details to database or do something else
                  // with the event details
                },
              ),
              ElevatedButton(
                child: Text('Delete Event',
                style: TextStyle(
                  color: Colors.white,
                ),),
                onPressed: () {
                  Navigator.pushNamed(context, '/Clubhead_home');
                  // TODO: Save event details to database or do something else
                  // with the event details
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
