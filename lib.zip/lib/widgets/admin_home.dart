import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/src/material/bottom_navigation_bar.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:eventbuzz/auth.dart';
import 'package:firebase_auth/firebase_auth.dart';
class Admin_home extends StatefulWidget {
  const Admin_home({Key? key}) : super(key: key);

  @override
  _Admin_homeState createState() => _Admin_homeState();
}

class _Admin_homeState extends State<Admin_home> {
  final User? user = Auth().currentUser;

  Future<void> signOut() async {
    await Auth().signOut();
  }
  Widget _signOutButton()
  {
    return ElevatedButton(
      onPressed: signOut,
      child: const Text('Sign Out'),
    );
  }
  int _selectedIndex = 0;
  String selectedType = '';
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }
  onWillPop(context) async {
    SystemChannels.platform.invokeMethod('SystemNavigator.pop');
    return false;
  }
  final RestorableInt _counter = RestorableInt(0);
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () => onWillPop(context),
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Admin Home Page'),
          centerTitle: true,
        ),
        drawer: Drawer(
          child: ListView(
            // Important: Remove any padding from the ListView.
            padding: EdgeInsets.zero,
            children: [
              const DrawerHeader(
                decoration: BoxDecoration(
                  color: Colors.blue,
                ),
                child: Text('',
                  style:TextStyle(
                    fontSize: 30,
                  ),),
              ),
              _signOutButton(),
              // _signOutButton(),
            ],
          ),
        ),
        body:Column(
            crossAxisAlignment: CrossAxisAlignment.center,

            children : <Widget> [
              Card(
                margin: const EdgeInsets.fromLTRB(20,120,20,0),
                color: Colors.lightGreenAccent,
                child : new InkWell(
                  onTap: () {
                    Navigator.pushNamed(context, '/addclub');
                  },
                  child: Center(
                    child: ListTile(
                        title: new Center(
                          child: Text('Add Club/Sport'),
                        )
                    ),
                  ),

                ),
              ),
              Card(
                margin: const EdgeInsets.fromLTRB(20,20,20,0),
                color: Colors.lightGreenAccent,
                child : new InkWell(
                  onTap: (){
                    Navigator.pushNamed(context, '/view_CS');
                  },
                  child: ListTile(
                      title: new Center(
                        child : Text('View Club/Sports'),
                      )
                  ),
                ),
              ),
              Card(
                margin: const EdgeInsets.fromLTRB(20, 20, 20, 0),
                color: Colors.lightGreenAccent,
                child : InkWell(
                  onTap: (){
                    Navigator.pushNamed(context, '/requests');
                  },
                  child: ListTile(
                      title: new Center(
                        child: Text('Requests'),
                      )
                  ),
                ),
              ),
              Card(
                margin: const EdgeInsets.fromLTRB(20,20,20,0),
                color: Colors.lightGreenAccent,
                child : InkWell(
                  onTap: (){
                    Navigator.pushNamed(context, '/csheads');
                  },
                  child: ListTile(
                      title: new Center(
                        child: Text('View CLubheads/Sportheads'),
                      )
                  ),
                ),
              ),
              Card(
                margin: const EdgeInsets.fromLTRB(20,20,20,0),
                color: Colors.lightGreenAccent,
                child : InkWell(
                  onTap: (){
                    Navigator.pushNamed(context, '/venue_master');
                  },
                  child: ListTile(
                      title: new Center(
                        child: Text('Venue Master'),
                      )
                  ),
                ),
              ),


            ]
        ),
        bottomNavigationBar: BottomNavigationBar(
          backgroundColor: Colors.blue,
          items: const <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              icon: Icon(Icons.home),
              label: 'Home',
            ),
          ],
          selectedItemColor: Colors.black,
          currentIndex: _selectedIndex,
          onTap: _onItemTapped,
        ),
      ),
    );
  }
}
