import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'view_liked_clubs.dart';
import 'view_liked_events.dart';
import 'Past_Clubpage.dart';
import 'Ongoing_Clubpage.dart';
import 'Upcoming_Clubpage.dart';
class Clubhome extends StatefulWidget {
  const Clubhome({Key? key}) : super(key: key);
  @override
  State<Clubhome> createState() => _ClubhomeState();
}

final PageController _pageController = PageController();

class _ClubhomeState extends State<Clubhome> {
  int _selectedIndex = 0;
  String selectedType = '';

  String selectedType2 = '';

  static final List<Widget> _pages = <Widget>[


    PageView(
      controller: _pageController,
      children: [
        Upcoming_Clubpage('Upcoming Events'),
        Ongoing_Clubpage('Ongoing Events'),
        Past_Clubpage('Past Events'),
      ],
    ),
    Icon(
      Icons.notifications,
      size: 150,
    ),
    PageView(
      children: [
        Liked_Clubs('Liked Clubs'),
        Liked_Events('Liked Events'),
      ],
    ),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text(
          'Club Page',
        ),
        backgroundColor: const Color(0xff764abc),
      ),
      drawer: Drawer(
        child: ListView(
          // Important: Remove any padding from the ListView.
          padding: EdgeInsets.zero,
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.blue,
              ),
              child: Text('CLUBS AND SPORTS',
                style:TextStyle(
                  fontSize: 30,
                ),),
            ),
            ListTile(
              leading: Icon(
                Icons.home,
              ),
              title: const Text('Home'),
              onTap: () {
                Navigator.pushNamed(context,'/home');
              },
            ),
            ListTile(
              leading: Icon(
                Icons.music_note,
              ),
              title: const Text('Clubs'),
              onTap: () {
                Navigator.pushNamed(context,'/clubs');
              },
            ),


            ListTile(
              leading: Icon(
                Icons.sports,
              ),
              title: const Text('Sports'),
              onTap: () {
                Navigator.pushNamed(context,'/sports');
              },
            ),

            ListTile(
              leading: IconButton(
                icon: Icon(Icons.logout),
                onPressed: () async {
                  // final provider =
                  // Provider.of<GoogleSignInProvider>(context, listen: false);
                  // provider.logout();
                  await GoogleSignIn().signOut();
                  FirebaseAuth.instance.signOut();
                  Navigator.popUntil(context, ModalRoute.withName('/'));
                },
              ),
              title: const Text('Logout'),
            ),
          ],
        ),
      ),
      body: Stack(
        children: [
          Center(
            child: _pages.elementAt(_selectedIndex),
            // PageView(
            //   controller: _pageController,
            //   children: [
            //     Upcoming_Page('Upcoming Events'),
            //     Ongoing_Page('Ongoing Events'),
            //     Past_Page('Past Events'),
            //   ],
          ),
          // ),
        ],
      ),
    floatingActionButton: FloatingActionButton(
       onPressed: () {  },
      child: Icon(Icons.favorite,
        color: Colors.redAccent,
      ),
        backgroundColor: Colors.redAccent[100],
    ),

    );
  }
}

