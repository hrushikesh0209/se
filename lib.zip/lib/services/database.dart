import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:eventbuzz/models/eventclass.dart';



class DatabaseService {

  final String? uid;

  DatabaseService({ this.uid });

  // collection reference
  final CollectionReference eventcollection = FirebaseFirestore.instance.collection('events');

  Future<void> updateUserData(String starttime, String name, String endtime, String venue, String url, String description, String clubname,String date) async {
    return await eventcollection.doc(uid).set({
      'starttime': starttime,
      'name': name,
      'endtime': endtime,
      'url': url,
      'venue': venue,
      'description': description,
      'clubname': clubname,
      'date': date,
    });
  }

  // brew list from snapshot
  List<Events> _eventListFromSnapshot(QuerySnapshot snapshot) {
    return snapshot.docs.map((doc){
      //print(doc.data);
      return Events(
          name:   doc['name'] ?? '',
          starttime: doc['starttime'] ?? 0,
          endtime: doc['endtime'] ?? '0',
          email: doc['email']??'0',
          venue: doc['venue']??'0',
          description: doc['description']??'0',
          url: doc['url']??'0',
          clubname: doc['clubname']??'0',
          date: doc['date']??'0',
      );
    }).toList();
  }

  // get brews stream
  Stream<List<Events>> get events {
    return eventcollection.snapshots()
        .map(_eventListFromSnapshot);
  }

}