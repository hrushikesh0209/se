import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class Events {

  final String name;
  final String starttime;
  final String endtime;
  final String venue;
  final String url;
  final String email;
  final String description;
  final String clubname;
  final String date;

  Events({ required this.name, required this.email,required this.venue,required this.url,required this.description,required this.clubname,required this.date,required this.endtime,required this.starttime });

}